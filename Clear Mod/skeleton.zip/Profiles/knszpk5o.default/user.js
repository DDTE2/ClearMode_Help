user_pref("kmeleon.toolband.Menu.visibility", false);
/* ----- DO NOT EDIT ANYTHING ABOVE THIS LINE -------------------------------------------- */
