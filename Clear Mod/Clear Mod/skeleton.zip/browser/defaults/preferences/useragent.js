pref("kmeleon.privacy.useragent.nouseragent", false);

pref("kmeleon.privacy.useragent.Count", 8);
#pref("general.useragent.vendor", "K-Meleon");
#pref("general.useragent.vendorSub", "74.0");

pref("kmeleon.privacy.useragent1.name", "Firefox 31");
pref("kmeleon.privacy.useragent1.sites", "");
pref("kmeleon.privacy.useragent1.string", "Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0");

pref("kmeleon.privacy.useragent2.name", "Firefox 28");
pref("kmeleon.privacy.useragent2.sites", "");
pref("kmeleon.privacy.useragent2.string", "Mozilla/5.0 (X11; OpenBSD amd64; rv:28.0) Gecko/20100101 Firefox/28.0");

pref("kmeleon.privacy.useragent3.name", "Firefox 25");
pref("kmeleon.privacy.useragent3.sites", "");
pref("kmeleon.privacy.useragent3.string", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0");

pref("kmeleon.privacy.useragent4.name", "Opera 12");
pref("kmeleon.privacy.useragent4.sites", "");
pref("kmeleon.privacy.useragent4.string", "Opera/9.80 (Windows NT 6.1; U; es-ES) Presto/2.9.181 Version/12.00");

pref("kmeleon.privacy.useragent5.name", "Opera 9");
pref("kmeleon.privacy.useragent5.sites", "");
pref("kmeleon.privacy.useragent5.string", "Opera/9.80 (Windows NT 6.1; U; ko) Presto/2.7.62 Version/11.00");

pref("kmeleon.privacy.useragent6.name", "Chrome 37 Win");
pref("kmeleon.privacy.useragent6.sites", "");
pref("kmeleon.privacy.useragent6.string", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36");

pref("kmeleon.privacy.useragent7.name", "Chrome 36 Mac");
pref("kmeleon.privacy.useragent7.sites", "");
pref("kmeleon.privacy.useragent7.string", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1944.0 Safari/537.36");

pref("kmeleon.privacy.useragent8.name", "K-Meleon 75");
pref("kmeleon.privacy.useragent8.sites", "");
pref("kmeleon.privacy.useragent8.string", "Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 K-Meleon/75.0");






